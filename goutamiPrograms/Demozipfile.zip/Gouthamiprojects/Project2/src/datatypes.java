
public class datatypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=30;
		int b=20;
		int c=a+b;
		System.out.println(c);
		System.out.println("hello");
		System.out.println("hello"+c);
		System.out.println("hello\t" +c);
		System.out.println("hello\t"+c+"welcome");
		System.out.println("hello\n");
		 a=4567890;
		 int e=25;
		int  f=a+b;
		 System.out.println("java\t" +(30+20+10));
		

	}

}
