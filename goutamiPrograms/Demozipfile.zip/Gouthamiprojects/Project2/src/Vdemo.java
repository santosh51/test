import java.util.*;
public class Vdemo {

	public static void main(String[] args) {
		Vector v=new Vector();
		System.out.println(v);
		// TODO Auto-generated method stub

	}

}
