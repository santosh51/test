import java.util.*;
class inheritance
{
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int a=10;
		String str="hello";
		a=s.nextInt();
		str=s.next();
		System.out.println(a);
		System.out.println(str);
		
		int i=1,j=1;
		for(i=1;i<=3;i++)
		{
			System.out.println(" ");
			for(j=1;j<=4;j++)
			{
				System.out.print(j);
			}
		}


		

		
		
		// TODO Auto-generated method stub

	}

}
