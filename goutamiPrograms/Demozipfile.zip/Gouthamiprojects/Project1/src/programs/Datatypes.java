package programs;

public class Datatypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//integer
		int a=15;
		int b=20;
		int c=a+b;
		int d=a%b;
		int x=a*b;
		int v=a-b;
		int f=a/b;
		System.out.println(c);
		System.out.println(d);
		System.out.println(x);
		System.out.println(v);
		System.out.println(f);


	
		
	}

}
