package programs;

public class Program1 {

	public static void main(String[] args) {
		
		System.out.println(2+3);
		System.out.println("2+3");
		System.out.println(2%3);
		System.out.println(2-3);
		System.out.println(2/3);
		System.out.println(2*3);
		System.out.println(2^3);
	
		System.out.println("\tJava2");
		System.out.println("       Java1");
		System.out.println("1234567Java3");
		System.out.println("++++++++Java4");
		System.out.println("\t  Java programming");
		System.out.println("  \tJava programming");
		System.out.println("---\tJava programming");
		System.out.println("--------\tJava programming");
		System.out.println("\nJava programming");
		System.out.println("Java\n programming");
		System.out.print("Java programming\n");
		System.out.println("  \tJava programming");






		// TODO Auto-generated method stub

	}

}
