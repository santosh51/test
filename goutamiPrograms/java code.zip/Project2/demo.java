import java.util.*;
class demo
{
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int i,j,m,n;
		m= scanner.nextInt();
		System.out.println(m);
		n=scanner.nextInt();
		System.out.println(n);
		for(i=1;i<=m;i++)
		{
			System.out.println(" ");
			for(j=1;j<=n;j++)
			{
				System.out.print(j);
			}
		}
		
}
		

	


















